#!/bin/bash

set -e

bin/build_data.elf

echo "Building data: done.  Now you can run './build.sh'"
