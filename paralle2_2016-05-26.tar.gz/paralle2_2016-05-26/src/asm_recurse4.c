// version 4: as version 2 and 3, only change inside tfncall and Recurse1/2 declaration

#include "e-lib.h"

void Asm_Init(void);
void Recurse0(void);
void Recurse1(void);
void Recurse2(void);
void Recurse3(void);

const void * tfncall[13]={
   &Recurse0,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse2,
   
   &Recurse0,
   &Recurse1,
   &Recurse3,
};

//#######################################

int fn_idx=0;
int dummy=0;
int tstats[78]={0};
int ttile0[2]={0,1};
int ttile1[2]={2,3};
int ttile2[2]={4,5};

//#######################################

int main(void) {
  Asm_Init();
  return 0;
}
