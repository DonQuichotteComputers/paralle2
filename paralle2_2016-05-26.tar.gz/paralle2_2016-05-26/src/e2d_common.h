// 2016/04/28: changed uc to uint. From 112.8 s to 108.8 s   Morality: Epiphany really likes 32-bit uint ; 8-bit or 16-bit may give load stalls, remember "Table 22" from arch. manual.
// 2016/05/09: 78.92 s without any stats, or 84.92 s with. Compiler options -mshort-calls, etc.
// 2016/05/26: 66.86 s without any stats -- full assembly :)

#define CORE_N 16
#define STATS
#ifdef STATS
  #define macro_globaltrace(niveau) out.globaltsolN[niveau]++;
#else
  #define macro_globaltrace(niveau) //gain 6.7 % without !  Even 6 s (84.92 s -> 78.92 s)
#endif

// to DEVICE
#pragma pack(4)
typedef struct S_input {
	int64_t tuile2do;
	int bordertuile2do;
	char tdam[180];
}Sinput;
// from DEVICE
typedef struct S_output {
	int globaltsolN[80];
  int globalres;
  int align8;
}Soutput;
// shared MEMORY
typedef struct S_io {
  int     tcmd[CORE_N];
  Sinput  tin [CORE_N];
  Soutput tout[CORE_N];
}Sio;

#define SHARED_RAM (0x01000000)
#define CMD_LEN (CORE_N * sizeof(uint)) // ARM handling Epiphany tasks: start, end
#define CMD_INIT 0x80000000 // host init
#define CMD_DONE 0x40000000 // eCore did the job properly (probably ; some bug might crush this word but it's highly improbable)

// tmp variables for DEVICE, trying a workaround for the -msmall16 compilation option
typedef struct S_tmp {
  int fn_idx;
  char ttiles[64 + 1 + 32 + 3]; // align 4
}Stmp;

// Epiphany local offsets
#define SHARED_IN  0x6000
#define SHARED_OUT (SHARED_IN  + sizeof(Sinput))
#define R_IDX      (SHARED_OUT + sizeof(Soutput))

// specific to the project

#define NORTH 0
#define EAST  1
#define SOUTH 2
#define WEST  3

#define B1N   0
#define C1N  10
#define C2N  11
#define C3N  12
#define C4N  13
#define C5N  14
#define C6N  15
#define C7N  16
#define C8N  17
#define C9N  18
#define C10N 19

#define B1E   90
#define C1E   99
#define C2E  100
#define C3E  101
#define C4E  102
#define C5E  103
#define C6E  104
#define C7E  105
#define C8E  106
#define C9E  107

#define BORDERCOLOR_D 0
#define BORDERCOLOR_G 4
#define BORDERCOLOR_I 9
#define BORDERCOLOR_N 19 // 19 colors ; 1st one is empty, colors 1-4 stand for D(roite), 5-8 for G(auche), 9-18 for I(nterieur)
