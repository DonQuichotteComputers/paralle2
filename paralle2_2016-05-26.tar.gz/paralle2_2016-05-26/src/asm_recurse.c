#include "e-lib.h" // mandatory even for a minimalist design -- e_get_coreid(), e_read(), e_write()

/*
 * DonQuichotteComputers (at) gmail (dot) com: 2016/05/22 testing recursive functions, assembly canvas from a C canvas :)
 * 
 * (we had a 1st lesson, recurse.c ; we decoded the generated assembly canvas with e-run)
 *
 * -> 2nd lesson, asm_recurse.c + recurse.S: 
 *   - read this .c file
 *   - compile with  ./asm_recurse.sh ;    
 *   - trace   with  e-run --trace-file asm_recurse -t asm_recurse.elf
 *
 */

void Asm_Init(void);
void Recurse0(void);
//void Recurse1(void);
//void Recurse2(void);
void Recurse3(void);

const void * tfncall[13]={
/*
   &Recurse0,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse1,
   &Recurse2,
  
   &Recurse0,
   &Recurse1,
*/
   &Recurse0, // <!> forgetting the '&' would load Recurse0[0] instead of its offset
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse3,
};

//#######################################

int fn_idx=0;
int dummy=0;
int tstats[78]={0};
int ttile0[2]={0,1};
int ttile1[2]={2,3};
int ttile2[2]={4,5};

//#######################################

int main(void) {
	// e_coreid_t coreid;
  int row, col, cmdI;
  int fn1;
  
  Asm_Init();
  // volatile: disable any optimization. Normal: WE write the optimized code :P
#define as(x) __asm__ volatile(x);
  //as("mov r0, %low(_Asm_Init)"); // %low() --> low 16-bit of an offset, a 32-bit value
  //as("jalr r0"); // a bit like the x86 asm "call eax" ; the Link Register LR alias 'lr' will keep the return address...
  // ... and the return address is just here ! Just after the 'call' 
  // as the register sp is NOT linked with the lr, you see the issue with recursive function calls: the LR must itself be saved & restored for 'non-leaf' functions
  
  // OK why are you still here ? Everything's in "recurse.S" from now on
  // do you know why we use .S suffix and not .s for assembly ? Who knows the difference ?
  // ...
  // .S allows the e-gcc preprocessor to do its job, a pretty nice job indeed.
  // It will allow us to use "#define" which is pretty cool for renaming the registers with something meaningful... better maintenance, readability, less bugs...
  
  return 0;
}
