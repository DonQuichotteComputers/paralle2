// version 2: no comments, make it clearer

#include "e-lib.h"

void Asm_Init(void);
void Recurse0(void);
//void Recurse1(void);
//void Recurse2(void);
void Recurse3(void);

const void * tfncall[13]={
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse0,
   &Recurse3,
};

//#######################################

int fn_idx=0;
int dummy=0;
int tstats[78]={0};
int ttile0[2]={0,1};
int ttile1[2]={2,3};
int ttile2[2]={4,5};

//#######################################

int main(void) {
  Asm_Init();
  return 0;
}
