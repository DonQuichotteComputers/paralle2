#include "e-lib.h" // mandatory even for a minimalist design -- e_get_coreid(), e_read(), e_write()

/*
 * DonQuichotteComputers (at) gmail (dot) com: 2016/05/17 testing recursive functions, assembly canvas from a C canvas :)
 * 
 * Decode the assembly canvas with e-run
 *
 */
// my semantic
#define LOOP1(x) for(fn1=0;fn1<(x);fn1++)

void Recurse0(void);
void Recurse1(void);
void Recurse2(void);
void Recurse3(void);

const void * tfncall[13]={
   Recurse0,
   Recurse1,
   Recurse1,
   Recurse1,
   Recurse1,
   Recurse1,
   Recurse1,
   Recurse1,
   Recurse1,
   Recurse2,
  
   Recurse0,
   Recurse1,
   Recurse3,
};

//#######################################
int fn_idx=0;
int dummy=0;
int tstats[78]={0};

void Recurse0(void) {
  int tuileN=2; 
  int ttuile[2]={0,1};
  int tuile, fn1;
  void (*ptr)(void);
  
  tstats[fn_idx]++;
  fn_idx++;
  ptr=tfncall[fn_idx];
  
  LOOP1(tuileN) {
    tuile=ttuile[fn1];
    (*ptr)();
    dummy ^= (1<<tuile);
  }

  fn_idx--;
}

void Recurse1(void) {
  int tuileN=2; 
  int ttuile[2]={2,3};
  int tuile, fn1;
  void (*ptr)(void);
  
  tstats[fn_idx]++;
  fn_idx++;
  ptr=tfncall[fn_idx];
  
  LOOP1(tuileN) {
    tuile=ttuile[fn1];
    (*ptr)();
    dummy ^= (1<<tuile);
  }

  fn_idx--;
}

void Recurse2(void) {
  int tuileN=2; 
  int ttuile[2]={4,5};
  int tuile, fn1;
  void (*ptr)(void);
  
  tstats[fn_idx]++;
  fn_idx++;
  ptr=tfncall[fn_idx];
  
  LOOP1(tuileN) {
    tuile=ttuile[fn1];
    (*ptr)();
    dummy ^= (1<<tuile);
  }

  fn_idx--;
}

void Recurse3(void) {
  tstats[fn_idx]++;
}

//#######################################

int main(void) {
	// e_coreid_t coreid;
  int row, col, cmdI;
  int fn1, fn2;
  void (*ptr)(void);
  
  asm volatile ("gid"); // disabling IRQ to enable the hardware loops

  fn_idx=0;
  ptr=tfncall[0];
  //(*ptr)(); // try this, it will fail: *ptr();
  
  Recurse0();
  
  LOOP1(13) {
    fn2=tstats[fn1]; // reading stats ; expected: 1 2 4 8 16... 4096
  }
  
  asm volatile ("gie"); // e_irq_global_mask(E_TRUE);
  
  return 0;
}
