//KO #pragma long_call  //because of e_read / e_write  crash when option -msmall16
#include "e-lib.h" //mandatory even for a minimalist design -- e_get_coreid(), e_read(), e_write()
//KO #pragma short_call

#define CORE_N 16

#define uint64_t	unsigned long long
#define int64_t		long long

//to DEVICE
#pragma pack(4)
typedef struct S_input {
	uint64_t tuile2do;
	uint bordertuile2do;
	uint tdam[180];
}Sinput;
//from DEVICE
#pragma pack(4)
typedef struct S_output {
	uint64_t globaltsolN[80];
  uint globalres;
  uint align8;
}Soutput;
//shared MEMORY
#pragma pack(4)
typedef struct S_io {
  uint    tcmd[CORE_N];
  Sinput  tin [CORE_N];
  Soutput tout[CORE_N];
}Sio;

#define SHARED_RAM 0x01000000
#define CMD_LEN (CORE_N * sizeof(uint)) //ARM handling Epiphany tasks: start, end
#define CMD_INIT 0x80000000 //host init
#define CMD_DONE 0x40000000 //eCore did the job properly (probably ; some bug might crush this word but it's highly improbable)

//ARM <-> Epiphany
#define SHARED_IN  0x6000 // (SHARED_RAM + CMD_LEN)
#define SHARED_OUT (SHARED_IN  + sizeof(Sinput))

//avoid stdint.h
#define uint8_t		unsigned char
#define uint16_t	unsigned short
#define uint32_t	unsigned int

#define int8_t		char
#define int16_t		short
#define int32_t		int

//volatile Sinput  in;
//volatile Soutput out;
Sinput  in  SECTION(".data_bank3");//0x6000
Soutput out SECTION(".data_bank3");//0x6000 + sizeof(Sinput)


//from the FFT example
/* Optimized memcpy */
    /* Only supports double word aligned pointer and len must be a multiple
     * of 32 bytes ! */
static void __attribute__ ((long_call)) memcpy_aligned(void *dst, void *src, int len) {
	__asm__ __volatile__ (
		"lsr %[len], %[len], #5		\n"
		"movts lc, %[len]		\n"
		"mov %[len], %%low(1f)		\n"
		"movt %[len], %%high(1f)	\n"
		"movts ls, %[len]		\n"
		"mov %[len], %%low(2f - 4)	\n"
		"movt %[len], %%high(2f - 4)	\n"
		"movts le, %[len]		\n"
		".balignw 8,0x01a2		\n"
		"1:				\n"
		"ldrd r52, [%[src]], #1		\n"
		"ldrd r54, [%[src]], #1		\n"
		"ldrd r56, [%[src]], #1		\n"
		"ldrd r58, [%[src]], #1		\n"
		"strd r52, [%[dst]], #1		\n"
		"strd r54, [%[dst]], #1		\n"
		"strd r56, [%[dst]], #1		\n"
		"strd r58, [%[dst]], #1		\n"
		"2:				\n"

		: [dst] "+r" (dst), [src] "+r" (src), [len] "+r" (len)
		:
		: "r52", "r53", "r54", "r55",
		  "r56", "r57", "r58", "r59",
		  "lc", "ls", "le", "memory"
	);
}

//#######################################

int main(void) {
  uint fn1;
  e_coreid_t coreid;
  int row, col, cmdI;
  uint *Pcmd;//pointer for retrieving the shared memory
  uint *Psrc;
  uint *Pdest;

  coreid=e_get_coreid();//query the coreID from hardware
  row=(coreid>>6) - 32;//dirty but OK for MY 16-core Epiphany
  col=(coreid&15) - 8;
  cmdI=(row<<2) + col;

  // e_read((void *)&e_group_config, (void *)&in, 0, 0, (const void *)SHARED_RAM + CMD_LEN + (cmdI * sizeof(Sinput)), sizeof(Sinput));
  //   core (0,0) will NOT read it: DMA cannot operate from input core X to output core X !
  // => choose the alternate syntax e_read(...e_emem_config), it's a slower 'e_memcpy' I would say, but with no restriction at all
//  e_read((void *)&e_emem_config, (void *)&in, 0, 0, (const void *)SHARED_RAM + CMD_LEN + (cmdI * sizeof(Sinput)), sizeof(Sinput));

  // <!> this e_read does NOT support the compilation option -msmall16 ; suppress it, e_write too: everything's OK
  //__attribute__ ((long_call)) e_read((unsigned int *)&e_emem_config, (void *)&in.tuile2do, 0, 0, (unsigned int *)(SHARED_RAM + CMD_LEN + (cmdI * sizeof(Sinput))), sizeof(Sinput));
  #pragma long_call //no use :/ -msmall16 crushes e_read/e_write/ copy from core to SDRAM
  e_read((unsigned int *)&e_emem_config, (void *)&in.tuile2do, 0, 0, (unsigned int *)(SHARED_RAM + CMD_LEN + (cmdI * sizeof(Sinput))), sizeof(Sinput));
  
  //nasty difference: (uint *)(src + something) != (uint *)src + something... ???
  //memcpy_aligned((void *)&in.tuile2do, (unsigned int *)(SHARED_RAM + CMD_LEN + (cmdI * sizeof(Sinput))), sizeof(Sinput));
  //Psrc=(void *) (SHARED_RAM + CMD_LEN + (cmdI * sizeof(Sinput)));
  //Pdest=(void *)0x6000;
  //for(fn1=0; fn1<sizeof(Sinput)/4; fn1++) {
    //*Pdest=*Psrc;
    //Pdest++;
    //Psrc++;
  //}
  //memcpy_aligned((void *)&in.tuile2do, (void *)Psrc, sizeof(Sinput));
  //memcpy_aligned((void *)&in.tuile2do, (void *)Psrc, sizeof(Sinput));

  // <!> this e_write does NOT support the compilation option -msmall16 ; suppress it, everything's OK
  //e_write((void *)&e_emem_config, (unsigned int *)&out, 0, 0, (unsigned int *)SHARED_RAM + CMD_LEN + (CORE_N * sizeof(Sinput)) + (cmdI * sizeof(Soutput)), sizeof(Soutput));
  //memcpy_aligned((unsigned int *)SHARED_RAM + CMD_LEN + (CORE_N * sizeof(Sinput)) + (cmdI * sizeof(Soutput)), (void *)&out.globaltsolN[0], sizeof(Soutput));

  Pcmd=(void *) (SHARED_RAM + (cmdI * 4));
  *Pcmd=CMD_DONE;//??? why does this thing work in EVERY situation, whereas memcpy or a single 4-byte copy sequence doesn't ? It's basically the same.
  
  return 0;
}
